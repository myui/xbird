#export ANT_OPTS="-Xmx512m"

ant -Duser.name="Makoto YUI"
